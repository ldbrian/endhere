'use client';

import {
  FEATURED_SEED_FRAGMENTS,
  V2_FRAGMENTS_KEY,
  V2_OWNER_KEY,
  createFragmentId,
  createOwnerId,
  type Fragment,
  type FragmentDraft,
} from './fragments';

function canUseStorage() {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function getLocalOwnerId() {
  if (!canUseStorage()) return 'server';

  const existing = window.localStorage.getItem(V2_OWNER_KEY);
  if (existing) return existing;

  const next = createOwnerId();
  window.localStorage.setItem(V2_OWNER_KEY, next);
  return next;
}

export function readLocalFragments() {
  if (!canUseStorage()) return [];

  try {
    const raw = window.localStorage.getItem(V2_FRAGMENTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Fragment[]) : [];
  } catch {
    return [];
  }
}

export function writeLocalFragments(fragments: Fragment[]) {
  if (!canUseStorage()) return;
  window.localStorage.setItem(V2_FRAGMENTS_KEY, JSON.stringify(fragments));
}

export function createLocalFragment(draft: FragmentDraft) {
  const now = new Date().toISOString();
  const fragment: Fragment = {
    id: createFragmentId(),
    owner_id: getLocalOwnerId(),
    title: draft.title,
    original_content: draft.original_content,
    narration_content: draft.narration_content,
    visibility: draft.visibility,
    allow_shopkeeper_review: draft.allow_shopkeeper_review,
    shopkeeper_comment: null,
    meta: {
      source: 'manual',
    },
    created_at: now,
    updated_at: now,
  };

  const nextFragments = [fragment, ...readLocalFragments()];
  writeLocalFragments(nextFragments);
  return fragment;
}

export function getFeaturedExhibit() {
  const publicLocal = readLocalFragments()
    .filter((fragment) => fragment.visibility === 'public')
    .sort((a, b) => {
      const bScore = b.meta.quality_score || 0;
      const aScore = a.meta.quality_score || 0;
      return bScore - aScore || Date.parse(b.created_at) - Date.parse(a.created_at);
    });

  return publicLocal[0] || FEATURED_SEED_FRAGMENTS[0];
}
