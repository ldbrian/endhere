'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { track } from '../lib/track'
import { getCustomerMemory } from '../lib/memory'

const GIFTS = [
  { id: 'milk', name: '待用热牛奶', icon: '🥛', price: '￥ 4.9', desc: '纯粹的情绪陪伴，给下个夜归人暖手。' },
  { id: 'bandaid', name: '创可贴', icon: '🩹', price: '￥ 2.0', desc: '替下一个人买单，帮他物理封印伤口。' },
  { id: 'match', name: '虚拟火柴', icon: '🔥', price: '￥ 1.0', desc: '递给下个人一根火柴，劝他彻底烧掉烂事。' },
]

// === 核心修改：将公共留言池改为按物品分类的专属留言池 ===
const GIFT_MSGS: Record<string, string[]> = {
  milk: [
    "今晚的夜路我替你跑了，早点睡。",
    "喝下这杯牛奶，烧掉这张小票，出门别回头。", // 👈 你的绝杀文案
    "（什么也没说，只留下了这杯热牛奶）"
  ],
  bandaid: [
    "这个创可贴我没用上，我挺过来了，你也可以。",
    "伤口正在结痂，先别去抠它了。",
    "（什么也没说，只留下了这个创可贴）"
  ],
  match: [
    "陌生人，把它烧了吧，出门别回头。",
    "我替你买单了。点火，然后忘掉它。",
    "（什么也没说，只留下了这根火柴）"
  ]
}

function CounterContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  
  const receiptId = searchParams.get('receiptId') || ''
  const mode = searchParams.get('mode') || 'basket' 
  const isManagerMode = mode === 'manager'

  const [mailboxStatus, setMailboxStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [mailboxMsg, setMailboxMsg] = useState('')

  const [visible, setVisible] = useState(false)
  const [droppedItem, setDroppedItem] = useState<any>(null)
  
  const [selectedGift, setSelectedGift] = useState<any>(null)
  const [selectedMsg, setSelectedMsg] = useState<string>('')
  const [payStep, setPayStep] = useState(false)
  const [paySuccess, setPaySuccess] = useState(false)

  useEffect(() => {
    track('view_counter', { mode, receipt_id: receiptId })
    setTimeout(() => setVisible(true), 100)

    if (!isManagerMode) {
      const profile = getCustomerMemory()
      const rand = Math.random()

      if (profile.visitCount > 3 && rand < 0.02) {
        setDroppedItem({
          type: 'coupon',
          icon: '🎫',
          name: '店长的打车免单券',
          time: new Date().toLocaleString('zh-CN', { hour12: false }), 
          msg: '拿着这张字条。如果有一天你在现实里碰巧打到了我的车，这单算我的。'
        })
        track('drop_miracle_coupon')
      } 
      else if (rand < 0.25) {
        const randomGift = GIFTS[Math.floor(Math.random() * GIFTS.length)]
        // === 核心修改：根据随机抽到的礼物，去对应的专属留言池里抽留言 ===
        const msgPool = GIFT_MSGS[randomGift.id]
        const randomMsg = msgPool[Math.floor(Math.random() * msgPool.length)]
        const hoursAgo = Math.floor(Math.random() * 20) + 1
        
        setDroppedItem({
          type: 'stranger',
          icon: randomGift.icon,
          name: randomGift.name,
          time: `${hoursAgo} 小时前`,
          msg: randomMsg
        })
        track('drop_stranger_gift', { gift_id: randomGift.id })
      }
    }
  }, [mode, receiptId, isManagerMode])

  const handleLeaveForManager = async () => {
    if (mailboxStatus === 'loading' || mailboxStatus === 'success') return
    setMailboxStatus('loading')
    
    try {
      const entries = JSON.parse(localStorage.getItem('entries') || '[]')
      const currentEntry = entries[0]
      const userContent = currentEntry?.content || currentEntry?.text || '无言的投递...'
      const aiContent = currentEntry?.rawResponse || '【系统提示】：用户选择了直接留言给店长。'

      const res = await fetch('/api/mailbox', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiptId, userMessage: userContent, aiResponse: aiContent })
      })
      const data = await res.json()
      
      if (data.success) {
        setMailboxStatus('success')
        setMailboxMsg(data.message)
        track('manager_mailbox_success', { receipt_id: receiptId })
        
        const storedEntries = JSON.parse(localStorage.getItem('entries') || '[]')
        const currentEntryIndex = storedEntries.findIndex((e: any) => e.receiptId === receiptId || e.id === storedEntries[0]?.id)
        if (currentEntryIndex !== -1) {
          storedEntries[currentEntryIndex].status = '等待回信'
          localStorage.setItem('entries', JSON.stringify(storedEntries))
        }
      } else {
        setMailboxStatus('error')
        setMailboxMsg(data.message)
      }
    } catch (e) {
      setMailboxStatus('error')
      setMailboxMsg('吧台抽屉卡住了，请稍后再试。')
    }
  }

  const handlePayComplete = () => {
    setPaySuccess(true)
    track('leave_gift_success', { gift_id: selectedGift?.id })
  }

  return (
    <div style={{
      width: '100%', maxWidth: '360px', display: 'flex', flexDirection: 'column',
      gap: '24px', padding: '60px 20px', margin: '0 auto',
      opacity: visible ? 1 : 0, transition: 'opacity 0.6s ease',
    }}>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'center', textAlign: 'center', marginBottom: '8px' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', letterSpacing: '0.3em' }}>
          END HERE COUNTER
        </p>
        <h1 style={{ color: 'var(--text-main)', fontSize: '24px', fontWeight: '300', letterSpacing: '0.15em' }}>
          午夜收银台
        </h1>
        <p style={{ color: 'var(--warm-yellow)', fontFamily: 'monospace', fontSize: '12px', opacity: 0.8, letterSpacing: '0.05em' }}>
          当前拿着的小票暗号: #{receiptId}
        </p>
      </div>

      {isManagerMode ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', animation: 'fadeIn 0.4s ease-out' }}>
          <div style={{ padding: '24px 20px', borderRadius: '12px', background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)', display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center' }}>
            <div style={{ textAlign: 'left', width: '100%', background: 'rgba(0,0,0,0.2)', padding: '16px', borderRadius: '8px', borderLeft: '2px solid var(--warm-yellow)' }}>
              <p style={{ color: 'var(--warm-yellow)', fontSize: '13px', fontWeight: 'bold', marginBottom: '8px', letterSpacing: '0.1em' }}>
                【吧台规矩】
              </p>
              <p style={{ color: 'var(--text-muted)', fontSize: '12px', lineHeight: '1.8' }}>
                1. 吧台每天<span style={{ color: 'var(--text-main)' }}>只收 7 张小票</span>，满了店长就收车。<br/>
                2. 留一瓶水的钱 (￥4.9) 当作提神费。<br/>
                3. <span style={{ color: 'var(--text-main)' }}>不承诺一定回，不退款。</span>看缘分。
              </p>
            </div>
            
            <img src="/pay_code.png" alt="投币码" style={{ width: '160px', height: '160px', filter: 'grayscale(100%) contrast(1.2)', opacity: 0.85, borderRadius: '8px' }} />
            
            <button
              onClick={handleLeaveForManager}
              disabled={mailboxStatus !== 'idle'}
              style={{
                width: '100%', padding: '16px', borderRadius: '8px', 
                background: 'rgba(245,200,66,0.1)', border: '1px solid rgba(245,200,66,0.3)',
                color: 'var(--warm-yellow)', fontSize: '14px', cursor: mailboxStatus === 'success' ? 'default' : 'pointer',
                fontWeight: 'bold', letterSpacing: '0.1em', transition: 'all 0.3s ease'
              }}
            >
              {mailboxStatus === 'idle' && '已塞入 ￥4.9，压下小票'}
              {mailboxStatus === 'loading' && '正在压入小票...'}
              {mailboxStatus === 'success' && '卷帘门正在拉下，去睡吧。'}
              {mailboxStatus === 'error' && '❌ ' + mailboxMsg}
            </button>
          </div>
        </div>
      ) : (
        <div style={{ 
          width: '100%', padding: '24px 20px', borderRadius: '12px', 
          background: 'rgba(255,255,255,0.01)', border: '1px solid rgba(255,255,255,0.08)', 
          textAlign: 'left', display: 'flex', flexDirection: 'column', gap: '20px', animation: 'fadeIn 0.4s ease-out'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '18px' }}>🛒</span>
            <span style={{ color: 'var(--text-main)', fontSize: '15px', letterSpacing: '0.1em', fontWeight: '500' }}>收银台旁边的铁筐</span>
          </div>

          {droppedItem ? (
            <div style={{ 
              padding: '16px', background: droppedItem.type === 'coupon' ? 'rgba(245,200,66,0.05)' : 'rgba(255,255,255,0.03)', 
              borderRadius: '8px', border: droppedItem.type === 'coupon' ? '1px dashed var(--warm-yellow)' : '1px dashed rgba(255,255,255,0.15)',
              display: 'flex', flexDirection: 'column', gap: '12px'
            }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', letterSpacing: '0.1em' }}>
                {droppedItem.type === 'coupon' ? '【奇迹掉落】' : `【${droppedItem.time} 某人留下】`}
              </p>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <span style={{ fontSize: '32px' }}>{droppedItem.icon}</span>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <span style={{ color: droppedItem.type === 'coupon' ? 'var(--warm-yellow)' : 'var(--text-main)', fontSize: '14px', fontWeight: 'bold' }}>{droppedItem.name}</span>
                </div>
              </div>
              <div style={{ padding: '12px', background: 'rgba(0,0,0,0.2)', borderRadius: '6px', borderLeft: droppedItem.type === 'coupon' ? '2px solid var(--warm-yellow)' : '2px solid rgba(255,255,255,0.2)' }}>
                <p style={{ color: 'var(--text-main)', fontSize: '13px', lineHeight: '1.7', fontStyle: 'italic', opacity: 0.9 }}>"{droppedItem.msg}"</p>
              </div>
              {droppedItem.type === 'coupon' && (
                <p style={{ fontFamily: 'monospace', fontSize: '10px', color: 'var(--warm-yellow)', opacity: 0.6, textAlign: 'right', margin: 0 }}>
                  [核对时间戳: {droppedItem.time}]
                </p>
              )}
            </div>
          ) : (
            <p style={{ color: 'var(--text-muted)', fontSize: '12px', lineHeight: '1.7', opacity: 0.5, fontStyle: 'italic' }}>
              筐底空空的。在这个城市里，大家今晚都在自顾不暇地赶路。
            </p>
          )}

          <div style={{ width: '100%', height: '1px', borderTop: '1px dashed rgba(255,255,255,0.1)' }} />

          {!payStep && !paySuccess ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <p style={{ color: 'var(--text-main)', fontSize: '13px', letterSpacing: '0.1em' }}>你要往里面放点什么吗？</p>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {GIFTS.map(gift => (
                  <button 
                    key={gift.id}
                    onClick={() => { setSelectedGift(gift); setPayStep(true); setSelectedMsg(''); }}
                    style={{ 
                      width: '100%', padding: '14px', borderRadius: '8px', 
                      background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)',
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      cursor: 'pointer', transition: 'all 0.2s', textAlign: 'left'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontSize: '20px' }}>{gift.icon}</span>
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ color: 'var(--text-main)', fontSize: '13px' }}>{gift.name}</span>
                        <span style={{ color: 'var(--text-muted)', fontSize: '11px', opacity: 0.7 }}>{gift.desc}</span>
                      </div>
                    </div>
                    <span style={{ color: 'var(--warm-yellow)', fontSize: '12px', fontWeight: 'bold' }}>{gift.price}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : payStep && !paySuccess ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', animation: 'fadeIn 0.3s ease' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', paddingBottom: '12px', borderBottom: '1px dashed rgba(255,255,255,0.1)' }}>
                <span style={{ fontSize: '24px' }}>{selectedGift.icon}</span>
                <span style={{ color: 'var(--text-main)', fontSize: '14px' }}>留一份【{selectedGift.name}】</span>
              </div>
              
              <p style={{ color: 'var(--text-muted)', fontSize: '12px' }}>只能从下面选一句话贴在上面：</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {/* === 核心修改：只映射当前礼物专属的留言池 === */}
                {GIFT_MSGS[selectedGift.id].map((msg, idx) => (
                  <div 
                    key={idx} 
                    onClick={() => setSelectedMsg(msg)}
                    style={{ 
                      padding: '12px', borderRadius: '6px', border: `1px solid ${selectedMsg === msg ? 'var(--warm-yellow)' : 'rgba(255,255,255,0.1)'}`, 
                      background: selectedMsg === msg ? 'rgba(245,200,66,0.08)' : 'transparent',
                      color: selectedMsg === msg ? 'var(--warm-yellow)' : 'var(--text-muted)', 
                      fontSize: '12px', cursor: 'pointer', transition: 'all 0.2s'
                    }}
                  >
                    {msg}
                  </div>
                ))}
              </div>

              {selectedMsg && (
                <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
                  <img src="/pay_code.png" alt="打赏码" style={{ width: '120px', height: '120px', filter: 'grayscale(100%) contrast(1.2)', opacity: 0.85, borderRadius: '8px' }} />
                  <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center' }}>扫码支付 {selectedGift.price}</p>
                  
                  <div style={{ display: 'flex', width: '100%', gap: '12px' }}>
                    <button onClick={() => { setPayStep(false); setSelectedMsg(''); }} style={{ flex: 1, padding: '12px', background: 'transparent', border: '1px solid var(--border)', color: 'var(--text-muted)', borderRadius: '8px', fontSize: '13px' }}>返回</button>
                    <button onClick={handlePayComplete} style={{ flex: 2, padding: '12px', background: 'rgba(245,200,66,0.1)', border: '1px solid rgba(245,200,66,0.3)', color: 'var(--warm-yellow)', borderRadius: '8px', fontSize: '13px', fontWeight: 'bold' }}>我已经付了</button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '24px 0', animation: 'fadeIn 0.5s ease' }}>
              <span style={{ fontSize: '32px', opacity: 0.8 }}>📦</span>
              <p style={{ color: 'var(--warm-yellow)', fontSize: '14px', marginTop: '12px', letterSpacing: '0.1em' }}>已经放进铁筐里了。</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '12px', marginTop: '8px', opacity: 0.7 }}>它会在某个深夜，掉落到另一个人手里。</p>
            </div>
          )}
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '12px' }}>
        <button 
          onClick={() => router.push('/archive')} 
          style={{ width: '100%', padding: '14px', borderRadius: '12px', border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-main)', fontSize: '13px', letterSpacing: '0.15em', cursor: 'pointer', opacity: 0.8 }}
        >
          去看我的抽屉
        </button>
        <button 
          onClick={() => router.push('/')} 
          style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '12px', cursor: 'pointer', opacity: 0.5, letterSpacing: '0.1em', marginTop: '8px' }}
        >
          回到店外
        </button>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

export default function CounterPage() {
  return (
    <Suspense fallback={<div style={{ textAlign: 'center', marginTop: '100px', color: 'var(--text-muted)' }}>走向收银台...</div>}>
      <CounterContent />
    </Suspense>
  )
}