'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { track } from '../lib/track'

// 遗留物/命运物件（保持不变）
const ITEMS = [
  { id: 'candle', icon: '🕯️', name: '深夜的烛光', desc: '你在最黑的时候，还是点了一盏灯。' },
  { id: 'rain', icon: '🌧️', name: '一场及时的雨', desc: '有些事，需要被冲刷一遍才能继续。' },
  { id: 'tea', icon: '🍵', name: '冷掉的茶', desc: '你顾着难过，忘了喝。没关系。' },
  { id: 'ticket', icon: '🎫', name: '一张旧车票', desc: '到站了。这段路，到此为止。' },
  { id: 'stone', icon: '🪨', name: '一块普通的石头', desc: '它什么都不做，但它在。' },
  { id: 'moon', icon: '🌙', name: '凌晨三点的月亮', desc: '它见过很多人的难熬，你不是第一个。' },
  { id: 'match', icon: '🔥', name: '一根火柴', desc: '划亮过，就够了。' },
]

export default function DonePage() {
  const [item, setItem] = useState<any>(null)
  const [visible, setVisible] = useState(false)
  const [scoreEnd, setScoreEnd] = useState(5)
  const [saved, setSaved] = useState(false)
  const [receiptId, setReceiptId] = useState('')
  const [isManagerMode, setIsManagerMode] = useState(false)
  
  // 新增：销毁流程状态
  const [destroyState, setDestroyState] = useState<'none' | 'choosing' | 'crushing' | 'burning' | 'destroyed'>('none')
  
  const router = useRouter()

  useEffect(() => {
    const entries = JSON.parse(localStorage.getItem('entries') || '[]')
    const currentEntry = entries[0]
    
    const randStr = Math.random().toString(36).substring(2, 4).toUpperCase()
    const timestampStr = Date.now().toString().slice(-4)
    const newReceiptId = `EH-${randStr}${timestampStr}`
    setReceiptId(newReceiptId)

    if (currentEntry) {
      if (currentEntry.persona === 'Manager') {
        setIsManagerMode(true)
        setItem({ 
          id: 'manager_letter', 
          icon: '✉️', 
          name: '一封未读的留言', 
          desc: '它正安静地躺在吧台抽屉里，等待被店长拆开。' 
        })
      } else {
        if (currentEntry.destinedItem) {
          const dItem = currentEntry.destinedItem
          setItem({ id: dItem.id, icon: dItem.id === 'broken_scale' ? '⚖️' : (dItem.id === 'cracked_bowl' ? '🥣' : '⚓'), name: dItem.name, desc: dItem.desc })
        } else {
          setItem(ITEMS[Math.floor(Math.random() * ITEMS.length)])
        }
      }
    }

    setTimeout(() => setVisible(true), 100)
  }, [])

  const handleSave = () => {
    track('save_entry', { scoreEnd, item_id: item?.id })
    const entries = JSON.parse(localStorage.getItem('entries') || '[]')
    if (entries.length > 0) {
      entries[0].emotionEnd = scoreEnd
      entries[0].status = isManagerMode ? '未投递' : '已记录' 
      entries[0].item = item
      entries[0].receiptId = receiptId 
    }
    localStorage.setItem('entries', JSON.stringify(entries))
    setSaved(true)
  }

  // 免费销毁：揉碎
  const handleCrush = () => {
    setDestroyState('crushing')
    track('destroy_crush', { receipt_id: receiptId })
    setTimeout(() => {
      executeDeleteFromDB()
      setDestroyState('destroyed')
    }, 1500) // 动画时间
  }

  // 付费销毁：火柴火化
  const handleBurn = () => {
    setDestroyState('burning')
    track('destroy_burn', { receipt_id: receiptId })
    // 这里未来接入支付，目前直接走燃烧流程
    setTimeout(() => {
      executeDeleteFromDB()
      setDestroyState('destroyed')
    }, 3500) // 燃烧动画更长，更具仪式感
  }

  // 彻底从本地数据库抹除内容（核心逻辑）
  const executeDeleteFromDB = () => {
    const entries = JSON.parse(localStorage.getItem('entries') || '[]')
    if (entries.length > 0) {
      // 保留残骸，清空核心内容
      entries[0].content = '【此小票已被物理销毁，仅留灰烬】'
      entries[0].rawResponse = ''
      entries[0].analysis = ''
      entries[0].punchline = ''
      entries[0].status = '彻底销毁'
      entries[0].released = true
      localStorage.setItem('entries', JSON.stringify(entries))
    }
  }

  return (
    <div style={{
      width: '100%', maxWidth: '360px', display: 'flex', flexDirection: 'column',
      alignItems: 'center', gap: '28px', padding: '50px 20px',
      opacity: visible ? 1 : 0, transition: 'opacity 0.6s ease', margin: '0 auto',
      position: 'relative'
    }}>

      {/* 🧾 === 真实热敏纸实体小票 === */}
      {/* 增加扭曲揉碎（crushing）和 燃烧（burning）的动态 class */}
      <div 
        id="share-receipt" 
        className={`receipt-paper ${destroyState === 'crushing' ? 'crushing-anim' : ''} ${destroyState === 'burning' ? 'burning-anim' : ''}`}
        style={{
          width: '100%', display: destroyState === 'destroyed' ? 'none' : 'flex', flexDirection: 'column', gap: '24px', 
          padding: '36px 24px 40px', 
          background: '#fbfaf7', 
          color: '#2a2a2a', 
          boxShadow: '0 20px 40px rgba(0,0,0,0.4), 0 5px 15px rgba(0,0,0,0.2)',
          position: 'relative',
          fontFamily: 'monospace, "PingFang SC"',
          clipPath: 'polygon(0% 0%, 4% 2%, 8% 0%, 12% 2%, 16% 0%, 20% 2%, 24% 0%, 28% 2%, 32% 0%, 36% 2%, 40% 0%, 44% 2%, 48% 0%, 52% 2%, 56% 0%, 60% 2%, 64% 0%, 68% 2%, 72% 0%, 76% 2%, 80% 0%, 84% 2%, 88% 0%, 92% 2%, 96% 0%, 100% 2%, 100% 98%, 96% 100%, 92% 98%, 88% 100%, 84% 98%, 80% 100%, 76% 98%, 72% 100%, 68% 98%, 64% 100%, 60% 98%, 56% 100%, 52% 98%, 48% 100%, 44% 98%, 40% 100%, 36% 98%, 32% 100%, 28% 98%, 24% 100%, 20% 98%, 16% 100%, 12% 98%, 8% 100%, 4% 98%, 0% 100%)',
          transition: 'all 0.5s ease'
        }}
      >
        
        {/* 顶部伪造的物理条形码 */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', opacity: 0.7 }}>
          <div style={{ 
            width: '140px', height: '24px', 
            backgroundImage: 'linear-gradient(90deg, #2a2a2a 0px, #2a2a2a 2px, transparent 2px, transparent 4px, #2a2a2a 4px, #2a2a2a 5px, transparent 5px, transparent 8px, #2a2a2a 8px, #2a2a2a 12px, transparent 12px, transparent 14px, #2a2a2a 14px, #2a2a2a 15px, transparent 15px, transparent 18px, #2a2a2a 18px, #2a2a2a 20px, transparent 20px, transparent 22px, #2a2a2a 22px, #2a2a2a 26px)',
            backgroundSize: '28px 24px'
          }} />
          <p style={{ fontSize: '9px', letterSpacing: '3px', margin: 0 }}>*{receiptId}*</p>
        </div>

        <div style={{ width: '100%', height: '1px', borderTop: '1px dashed #8c8273', opacity: 0.3 }} />
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', textAlign: 'left' }}>
          <p style={{ fontSize: '11px', color: '#8f857a', letterSpacing: '0.2em', margin: 0 }}>
            {isManagerMode ? 'COUNTER TICKET' : 'MEMORIES RECORD'}
          </p>
          <h2 style={{ fontSize: '22px', fontWeight: 'bold', letterSpacing: '0.05em', margin: '4px 0 0', color: '#1a1612' }}>
            {isManagerMode ? '凭条已生成' : '一切到此为止'}
          </h2>
        </div>

        {item && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: '14px',
            padding: '16px', borderRadius: '4px', background: 'rgba(0,0,0,0.02)', 
            border: '1px solid rgba(0,0,0,0.05)', width: '100%', textAlign: 'left'
          }}>
            <div style={{ fontSize: '36px', lineHeight: 1 }}>{item.icon}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              <p style={{ color: '#1a1612', fontSize: '13px', fontWeight: 'bold', margin: 0 }}>
                【{item.name}】
              </p>
              <p style={{ color: '#6e655f', fontSize: '11px', lineHeight: '1.5', margin: 0 }}>{item.desc}</p>
            </div>
          </div>
        )}

        <div style={{ width: '100%', height: '1px', borderTop: '1px dashed #8c8273', opacity: 0.3 }} />

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', textAlign: 'left' }}>
          <div>
            <p style={{ fontSize: '12px', fontWeight: 'bold', margin: 0, color: '#1a1612' }}>END HERE 避难所</p>
            <p style={{ fontSize: '9px', color: '#8f857a', marginTop: '2px', margin: 0 }}>
              {new Date().toLocaleDateString('zh-CN')} {new Date().toLocaleTimeString('zh-CN', {hour12:false}).slice(0,5)}
            </p>
          </div>
        </div>
      </div>

      {/* 状态 1：撕小票前 */}
      {!saved && (
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '16px', padding: '24px', borderRadius: '12px', background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '12px', letterSpacing: '0.1em' }}>打出小票前，现在心情好点了吗？</p>
          <input type="range" min={1} max={10} value={scoreEnd} onChange={(e) => setScoreEnd(parseInt(e.target.value))} style={{ width: '100%', accentColor: 'var(--warm-yellow)', cursor: 'pointer' }} />
          <button onClick={handleSave} style={{ width: '100%', padding: '14px', borderRadius: '10px', border: '1px solid rgba(245,200,66,0.3)', background: 'rgba(245,200,66,0.08)', color: 'var(--warm-yellow)', fontSize: '13px', letterSpacing: '0.2em', cursor: 'pointer', fontWeight: 'bold' }}>
            嗞嗞 · 撕下小票
          </button>
        </div>
      )}

      {/* 状态 2：撕下小票后，出现决绝的命运岔路口 */}
      {saved && destroyState === 'none' && (
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '14px', animation: 'fadeIn 0.8s ease' }}>
          {isManagerMode ? (
            <button
              onClick={() => router.push(`/counter?receiptId=${receiptId}&mode=manager`)}
              style={{
                width: '100%', padding: '16px', borderRadius: '12px', 
                border: '1px dashed var(--warm-yellow)', background: 'rgba(245,200,66,0.04)',
                color: 'var(--warm-yellow)', fontSize: '14px', letterSpacing: '0.1em', cursor: 'pointer',
              }}
            >
              📥 去吧台把小票压在玻璃杯下
            </button>
          ) : (
            <>
              <button 
                onClick={() => setDestroyState('choosing')} 
                style={{ width: '100%', padding: '16px', borderRadius: '12px', border: '1px solid rgba(245,200,66,0.6)', background: 'rgba(245,200,66,0.08)', color: 'var(--warm-yellow)', fontSize: '14px', fontWeight: 'bold', letterSpacing: '0.15em', cursor: 'pointer', transition: 'all 0.3s' }}
              >
                到此为止 · End Here
              </button>

              <button 
                onClick={() => router.push('/archive')} 
                style={{ width: '100%', padding: '16px', borderRadius: '12px', border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-muted)', fontSize: '13px', letterSpacing: '0.15em', cursor: 'pointer' }}
              >
                暂时收进兜里
              </button>
            </>
          )}
        </div>
      )}

      {/* 状态 3：点击 End Here 后的销毁抉择 */}
      {destroyState === 'choosing' && (
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '12px', animation: 'fadeIn 0.3s ease' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', marginBottom: '8px', letterSpacing: '0.1em' }}>你要怎么处理这张小票？(动作不可逆)</p>
          
          <button onClick={handleCrush} style={{ width: '100%', padding: '14px', borderRadius: '10px', border: '1px solid var(--border)', background: 'rgba(255,255,255,0.03)', color: 'var(--text-muted)', fontSize: '13px', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>🗑️ 揉成一团扔了</span>
            <span style={{ fontSize: '11px', opacity: 0.5 }}>免费</span>
          </button>
          
          <button onClick={handleBurn} style={{ width: '100%', padding: '14px', borderRadius: '10px', border: '1px dashed #e87070', background: 'rgba(232,112,112,0.05)', color: '#e87070', fontSize: '13px', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>🔥 划根火柴烧成灰</span>
            <span style={{ fontSize: '11px', fontWeight: 'bold' }}>￥ 1.00</span>
          </button>
          
          <button onClick={() => setDestroyState('none')} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '12px', marginTop: '12px', opacity: 0.5, cursor: 'pointer' }}>
            算了，我再想想
          </button>
        </div>
      )}

      {/* 状态 4：销毁完成后的残烬状态 */}
      {destroyState === 'destroyed' && (
        <div style={{ width: '100%', textAlign: 'center', animation: 'fadeIn 1s ease', marginTop: '40px' }}>
          <div style={{ fontSize: '48px', opacity: 0.4, marginBottom: '20px' }}>💨</div>
          <p style={{ color: 'var(--text-main)', fontSize: '16px', letterSpacing: '0.2em', marginBottom: '8px' }}>风一吹，什么都没了。</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '12px', opacity: 0.6, marginBottom: '40px' }}>这件事已经从物理层面上被彻底抹杀。</p>
          <button onClick={() => router.push('/')} style={{ padding: '12px 32px', borderRadius: '8px', border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-muted)', fontSize: '12px', letterSpacing: '0.1em', cursor: 'pointer' }}>
            推门离开
          </button>
        </div>
      )}

      {/* 隐藏的角落：收银台旁边的铁筐 (仅在小票印出、未销毁时显示) */}
      {saved && destroyState !== 'destroyed' && (
        <div 
          onClick={() => router.push(`/counter?receiptId=${receiptId}&mode=basket`)}
          style={{ 
            position: 'absolute', bottom: '-40px', right: '10px', 
            cursor: 'pointer', opacity: 0.3, transition: 'opacity 0.3s',
            display: 'flex', alignItems: 'center', gap: '6px'
          }}
          onMouseEnter={e => e.currentTarget.style.opacity = '0.8'}
          onMouseLeave={e => e.currentTarget.style.opacity = '0.3'}
        >
          <span style={{ fontSize: '16px' }}>🛒</span>
          <span style={{ color: 'var(--text-muted)', fontSize: '10px', letterSpacing: '0.1em' }}>收银台旁边的铁筐</span>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        /* 揉碎动画：缩放、扭曲、变灰 */
        .crushing-anim {
          animation: crushPaper 1.5s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }
        @keyframes crushPaper {
          0% { transform: scale(1) rotate(0deg); opacity: 1; }
          40% { transform: scale(0.9) rotate(2deg) skew(2deg, 2deg); filter: grayscale(50%); }
          100% { transform: scale(0.1) rotate(45deg); opacity: 0; filter: blur(5px); }
        }
        /* 燃烧动画：变黑、发红、化为灰烬向上飘 */
        .burning-anim {
          animation: burnPaper 3.5s ease-in forwards;
        }
        @keyframes burnPaper {
          0% { filter: brightness(1) sepia(0); opacity: 1; transform: translateY(0); }
          30% { filter: brightness(0.6) sepia(0.8) hue-rotate(-20deg) saturate(3); opacity: 0.9; }
          60% { filter: brightness(0.2) sepia(1) hue-rotate(-50deg) saturate(5); opacity: 0.7; transform: translateY(-10px); }
          100% { filter: brightness(0) opacity(0); transform: translateY(-50px) scale(0.8); opacity: 0; }
        }
      `}</style>
    </div>
  )
}