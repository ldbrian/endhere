'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import type { Fragment } from './_core/fragments';
import { FEATURED_SEED_FRAGMENTS } from './_core/fragments';
import { getFeaturedExhibit } from './_core/storage';
import { useSpaceStore, type Scene } from '../store/useSpaceStore';

export default function V2HomePage() {
  const router = useRouter();
  const setScene = useSpaceStore((state) => state.setScene);
  const [featured, setFeatured] = useState<Fragment>(FEATURED_SEED_FRAGMENTS[0]);

  useEffect(() => {
    window.requestAnimationFrame(() => {
      setFeatured(getFeaturedExhibit());
    });
  }, []);

  const enterOldScene = (scene: Scene) => {
    setScene(scene);
    router.push('/');
  };

  return (
    <main className="relative min-h-dvh overflow-hidden bg-[#080808] text-zinc-200 selection:bg-zinc-800 selection:text-zinc-100">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(255,255,255,0.035),transparent_30%),linear-gradient(180deg,rgba(255,255,255,0.018)_0%,transparent_34%,rgba(255,255,255,0.012)_100%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-black/70 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-black/80 to-transparent" />

      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[430px] flex-col px-6 pb-10 pt-8">
        <header className="flex shrink-0 items-start justify-between">
          <div className="flex min-w-0 flex-col gap-2 opacity-60">
            <div className="flex items-center gap-3">
              <Image src="/logo.png" alt="End Here Logo" width={20} height={20} className="shrink-0 object-contain" />
              <span className="truncate text-[11px] tracking-[0.24em] text-zinc-500">END HERE</span>
            </div>
            <span className="text-[10px] tracking-[0.1em] text-zinc-600">Life Experience Archive</span>
          </div>

          <button
            onClick={() => enterOldScene('shopkeeper')}
            className="rounded-full border border-zinc-900 px-3 py-2 text-[10px] tracking-[0.16em] text-zinc-600 transition-colors duration-500 hover:border-zinc-700 hover:text-zinc-300"
          >
            店长
          </button>
        </header>

        <section className="flex shrink-0 flex-col items-center pt-12 text-center">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, ease: 'easeOut' }}
            className="max-w-[18em] text-[22px] font-light leading-[1.85] tracking-[0.08em] text-zinc-100"
          >
            这里不解答人生的意义。
            <br />
            只保管人生的体验。
          </motion.p>
        </section>

        <section className="flex flex-1 flex-col items-center justify-center py-10">
          <motion.article
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, ease: 'easeOut', delay: 0.1 }}
            className="w-full max-w-[320px]"
          >
            <div className="mb-6 flex items-center justify-between text-[10px] tracking-[0.2em] text-zinc-700">
              <span>今日展柜</span>
              <span>{featured.meta.source === 'seed' ? '人工精选' : '公开碎片'}</span>
            </div>

            <div className="relative border border-zinc-900/90 bg-zinc-950/30 px-7 py-8 shadow-[0_28px_80px_rgba(0,0,0,0.42)]">
              <div className="pointer-events-none absolute inset-x-6 top-5 h-px bg-gradient-to-r from-transparent via-zinc-800 to-transparent" />
              <h1 className="text-[22px] font-light leading-10 tracking-[0.08em] text-zinc-100">
                {featured.title}
              </h1>
              <p className="mt-7 whitespace-pre-wrap text-[14px] font-light leading-8 tracking-[0.06em] text-zinc-400">
                {featured.original_content}
              </p>
              {featured.narration_content && (
                <p className="mt-8 border-l border-zinc-800 pl-4 text-[13px] font-light leading-7 tracking-[0.06em] text-zinc-600">
                  {featured.narration_content}
                </p>
              )}
            </div>
          </motion.article>

          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut', delay: 0.22 }}
            className="mt-10 flex flex-col items-center text-center"
          >
            <p className="text-[13px] leading-7 tracking-[0.1em] text-zinc-600">
              这块碎片，
              <br />
              是否让你想起了什么？
            </p>
            <Link
              href="/v2/fragments/new"
              className="mt-9 text-[17px] tracking-[0.12em] text-zinc-100 transition-colors duration-500 hover:text-white"
            >
              [ 留下一块碎片 ]
            </Link>
          </motion.div>
        </section>

        <nav className="shrink-0 px-1 pb-2">
          <div className="mx-auto flex w-full max-w-[330px] items-center justify-between border-t border-zinc-900 pt-6 text-[11px] tracking-[0.1em] text-zinc-600">
            <button onClick={() => enterOldScene('nostalgia')} className="transition-colors duration-500 hover:text-zinc-300">
              我的痕迹
            </button>
            <button onClick={() => enterOldScene('mirror')} className="transition-colors duration-500 hover:text-zinc-300">
              照照镜子
            </button>
            <button onClick={() => enterOldScene('resting')} className="transition-colors duration-500 hover:text-zinc-300">
              发呆区
            </button>
            <button onClick={() => enterOldScene('shopkeeper')} className="transition-colors duration-500 hover:text-zinc-300">
              胶囊
            </button>
          </div>
        </nav>
      </div>
    </main>
  );
}
